#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_garbage_collection.c"
