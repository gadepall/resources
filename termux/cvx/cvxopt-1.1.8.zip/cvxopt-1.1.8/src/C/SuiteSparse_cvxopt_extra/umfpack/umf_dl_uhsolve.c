#define DLONG

#define CONJUGATE_SOLVE
#include "../../SuiteSparse/UMFPACK/Source/umf_utsolve.c"
