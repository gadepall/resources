#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_start_front.c"
