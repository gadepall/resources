#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_apply_order.c"
