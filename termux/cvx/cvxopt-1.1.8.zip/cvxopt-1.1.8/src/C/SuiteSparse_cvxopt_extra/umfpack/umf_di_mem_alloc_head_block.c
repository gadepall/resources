#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_mem_alloc_head_block.c"
