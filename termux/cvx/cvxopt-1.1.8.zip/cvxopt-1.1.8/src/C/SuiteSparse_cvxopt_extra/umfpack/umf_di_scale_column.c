#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_scale_column.c"
