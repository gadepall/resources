#define DINT
#define DROP
#include "../../SuiteSparse/UMFPACK/Source/umf_store_lu.c"
