#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_transpose.c"
